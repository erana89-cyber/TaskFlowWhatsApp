package com.taskflow.whatsapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.io.File;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity {
    private TaskStore store;
    private LinearLayout suggestionsBox;
    private LinearLayout tasksBox;
    private LinearLayout doneBox;
    private TextView statusText;
    private Switch autoSwitch;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { refresh(); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        store = new TaskStore(this);
        buildUi();
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter("com.taskflow.whatsapp.TASKS_CHANGED");
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);
    }

    @Override protected void onStop() { super.onStop(); unregisterReceiver(receiver); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = vbox();
        root.setPadding(dp(18), dp(22), dp(18), dp(36));
        scroll.addView(root);

        TextView title = text("TaskFlow", 30, true);
        root.addView(title);
        TextView subtitle = text("WhatsApp → משימה, בלי להעתיק ולהדביק", 16, false);
        subtitle.setTextColor(Color.DKGRAY);
        root.addView(subtitle, marginTop(4));

        statusText = text("", 14, false);
        root.addView(statusText, marginTop(18));

        Button access = new Button(this);
        access.setText("אפשר גישה להתראות WhatsApp");
        access.setAllCaps(false);
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        root.addView(access, marginTop(10));

        autoSwitch = new Switch(this);
        autoSwitch.setText("הוסף אוטומטית בקשות ברורות מאוד");
        autoSwitch.setChecked(store.isAutoAddStrong());
        autoSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> store.setAutoAddStrong(isChecked));
        root.addView(autoSwitch, marginTop(8));

        TextView privacy = text("הסינון מתבצע על המכשיר. האפליקציה בודקת רק התראות WhatsApp / WhatsApp Business ואינה שולחת את תוכן ההודעות לשרת.", 13, false);
        privacy.setTextColor(Color.GRAY);
        root.addView(privacy, marginTop(8));

        root.addView(sectionTitle("הוספה מהירה"), marginTop(24));
        EditText quick = new EditText(this);
        quick.setHint("לדוגמה: תתקשר ליעקב מחר ב־10:00");
        quick.setSingleLine(false);
        root.addView(quick, marginTop(8));
        Button add = new Button(this);
        add.setText("הוסף משימה");
        add.setAllCaps(false);
        add.setOnClickListener(v -> {
            String value = quick.getText().toString().trim();
            if (!value.isEmpty()) {
                store.addManual(value);
                quick.setText("");
                refresh();
            }
        });
        root.addView(add, marginTop(6));

        root.addView(sectionTitle("נכנס מ־WhatsApp"), marginTop(26));
        suggestionsBox = vbox();
        root.addView(suggestionsBox);

        root.addView(sectionTitle("המשימות שלי"), marginTop(28));
        tasksBox = vbox();
        root.addView(tasksBox);

        root.addView(sectionTitle("הושלמו"), marginTop(28));
        doneBox = vbox();
        root.addView(doneBox);

        setContentView(scroll);
    }

    private void refresh() {
        if (suggestionsBox == null) return;
        suggestionsBox.removeAllViews();
        tasksBox.removeAllViews();
        doneBox.removeAllViews();
        List<TaskStore.TaskItem> items = store.all();
        int suggested = 0, active = 0, done = 0;
        for (TaskStore.TaskItem t : items) {
            if ("suggested".equals(t.status)) {
                suggested++;
                suggestionsBox.addView(card(t, "suggested"), marginTop(10));
            } else if ("active".equals(t.status)) {
                active++;
                tasksBox.addView(card(t, "active"), marginTop(10));
            } else if ("done".equals(t.status)) {
                done++;
                doneBox.addView(card(t, "done"), marginTop(10));
            }
        }
        if (suggested == 0) suggestionsBox.addView(empty("אין כרגע הודעות שממתינות לאישור."));
        if (active == 0) tasksBox.addView(empty("אין כרגע משימות פעילות."));
        if (done == 0) doneBox.addView(empty("עדיין אין משימות שהושלמו."));
        boolean accessEnabled = isNotificationAccessEnabled();
        statusText.setText((accessEnabled ? "✓ קליטת WhatsApp פעילה" : "⚠ נדרשת הרשאת גישה להתראות")
                + "\nממתינות: " + suggested + "   •   פעילות: " + active + "   •   הושלמו: " + done);
        if (autoSwitch != null && autoSwitch.isChecked() != store.isAutoAddStrong()) autoSwitch.setChecked(store.isAutoAddStrong());
    }

    private View card(TaskStore.TaskItem t, String mode) {
        LinearLayout card = vbox();
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor("done".equals(mode) ? Color.rgb(244,248,244) : Color.rgb(247,247,247));
        bg.setCornerRadius(dp(16));
        card.setBackground(bg);

        TextView title = text(t.title == null || t.title.isEmpty() ? t.text : t.title, 17, true);
        title.setTextIsSelectable(true);
        card.addView(title);

        TextView sender = text(("whatsapp".equals(t.source) ? "מ־" : "") + t.sender, 13, false);
        sender.setTextColor(Color.DKGRAY);
        card.addView(sender, marginTop(5));

        if (t.text != null && t.title != null && !t.text.equals(t.title)) {
            TextView original = text(t.text, 14, false);
            original.setTextColor(Color.DKGRAY);
            original.setTextIsSelectable(true);
            card.addView(original, marginTop(5));
        }

        if (t.imagePath != null && !t.imagePath.isEmpty() && new File(t.imagePath).exists()) {
            ImageView image = new ImageView(this);
            image.setAdjustViewBounds(true);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setImageBitmap(BitmapFactory.decodeFile(t.imagePath));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(180));
            ip.topMargin = dp(8);
            card.addView(image, ip);
        }

        StringBuilder metaText = new StringBuilder();
        if (t.dueAt > 0) {
            metaText.append("יעד: ")
                    .append(DateFormat.getDateFormat(this).format(new Date(t.dueAt)))
                    .append(" ")
                    .append(DateFormat.getTimeFormat(this).format(new Date(t.dueAt)));
        }
        if ("high".equals(t.priority)) {
            if (metaText.length() > 0) metaText.append("   •   ");
            metaText.append("דחוף");
        }
        if ("suggested".equals(mode)) {
            if (metaText.length() > 0) metaText.append("   •   ");
            metaText.append("זיהוי ").append(t.confidence).append("%");
        }
        if (metaText.length() == 0) {
            metaText.append(DateFormat.getDateFormat(this).format(new Date(t.createdAt)))
                    .append(" ")
                    .append(DateFormat.getTimeFormat(this).format(new Date(t.createdAt)));
        }
        TextView meta = text(metaText.toString(), 12, false);
        meta.setTextColor("high".equals(t.priority) ? Color.rgb(180, 40, 40) : Color.GRAY);
        card.addView(meta, marginTop(6));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END);

        if ("suggested".equals(mode)) {
            actions.addView(actionButton("דחה", v -> { store.updateStatus(t.id, "rejected"); refresh(); }));
            actions.addView(actionButton("הוסף למשימות", v -> { store.updateStatus(t.id, "active"); refresh(); }));
        } else if ("active".equals(mode)) {
            actions.addView(actionButton("מחק", v -> confirmDelete(t)));
            actions.addView(actionButton("בוצע", v -> { store.updateStatus(t.id, "done"); refresh(); }));
        } else if ("done".equals(mode)) {
            actions.addView(actionButton("מחק", v -> confirmDelete(t)));
            actions.addView(actionButton("החזר", v -> { store.updateStatus(t.id, "active"); refresh(); }));
        }
        card.addView(actions, marginTop(8));
        return card;
    }

    private boolean isNotificationAccessEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return enabled != null && enabled.contains(getPackageName());
    }

    private void confirmDelete(TaskStore.TaskItem t) {
        new AlertDialog.Builder(this)
                .setTitle("למחוק משימה?")
                .setMessage(t.title == null ? t.text : t.title)
                .setNegativeButton("ביטול", null)
                .setPositiveButton("מחק", (d, w) -> { store.delete(t.id); refresh(); })
                .show();
    }

    private Button actionButton(String label, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(click);
        return b;
    }

    private TextView sectionTitle(String value) {
        TextView t = text(value, 21, true);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private TextView empty(String value) {
        TextView t = text(value, 14, false);
        t.setTextColor(Color.GRAY);
        t.setPadding(0, dp(12), 0, dp(12));
        return t;
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value == null ? "" : value);
        t.setTextSize(sp);
        t.setTextColor(Color.BLACK);
        t.setGravity(Gravity.START);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private ViewGroup.MarginLayoutParams marginTop(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(topDp);
        return p;
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
