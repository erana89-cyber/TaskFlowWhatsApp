package com.taskflow.whatsapp;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lightweight on-device task detector. No network calls and no message content leaves the phone. */
public final class TaskParser {
    private static final String[] STRONG_HE = {
            "תזכיר", "תטפל", "לטפל", "תבדוק", "לבדוק", "תשלח", "לשלוח", "תתקשר", "להתקשר",
            "תתאם", "לתאם", "תקבע", "לקבוע", "תכניס", "להכניס", "תוסיף", "להוסיף", "תוודא", "לוודא",
            "תעדכן", "לעדכן", "תכין", "להכין", "תקנה", "לקנות", "תביא", "להביא", "קח", "לקחת",
            "תזמין", "להזמין", "תשלם", "לשלם", "תחזיר", "להחזיר", "תאסוף", "לאסוף", "תעביר", "להעביר",
            "תברר", "לברר", "תסגור", "לסגור", "צריך", "צריכים", "בבקשה", "נא "
    };
    private static final String[] STRONG_EN = {
            "remind", "please", "can you", "need to", "check ", "send ", "call ", "schedule", "book ",
            "buy ", "pay ", "follow up", "update ", "review ", "confirm "
    };
    private static final String[] URGENT = {"דחוף", "בהקדם", "מייד", "מיד", "asap", "urgent"};

    private static final Pattern COLON_TIME = Pattern.compile("(?<!\\d)([01]?\\d|2[0-3]):([0-5]\\d)(?!\\d)");
    private static final Pattern WORD_TIME = Pattern.compile("(?:בשעה|ב[-־])\\s*([01]?\\d|2[0-3])(?:[:.]([0-5]\\d))?");

    private TaskParser() {}

    public static Result parse(String raw, long nowMillis) {
        String text = raw == null ? "" : raw.trim();
        String lower = text.toLowerCase(Locale.ROOT);
        Result r = new Result();
        r.originalText = text;
        r.title = compactTitle(text);
        r.priority = "normal";
        r.confidence = 0;

        boolean action = containsAny(lower, STRONG_HE) || containsAny(lower, STRONG_EN);
        if (action) r.confidence += 65;

        boolean urgent = containsAny(lower, URGENT);
        if (urgent) {
            r.priority = "high";
            r.confidence += 15;
        }

        Due due = parseDue(lower, nowMillis);
        r.dueAt = due.millis;
        if (due.foundDate) r.confidence += 20;
        if (due.foundTime) r.confidence += 10;

        if (lower.contains("?") && !action) r.confidence -= 10;
        if (text.length() < 3) r.confidence = 0;

        r.confidence = Math.max(0, Math.min(100, r.confidence));
        r.isTask = action && r.confidence >= 60;
        return r;
    }

    private static String compactTitle(String text) {
        if (text == null) return "";
        String s = text.replaceAll("\\s+", " ").trim();
        if (s.length() <= 110) return s;
        return s.substring(0, 107).trim() + "…";
    }

    private static boolean containsAny(String text, String[] terms) {
        for (String term : terms) if (text.contains(term)) return true;
        return false;
    }

    private static Due parseDue(String text, long nowMillis) {
        Calendar base = Calendar.getInstance();
        base.setTimeInMillis(nowMillis > 0 ? nowMillis : System.currentTimeMillis());
        Calendar due = (Calendar) base.clone();
        boolean foundDate = false;

        if (text.contains("מחר") || text.contains("tomorrow")) {
            due.add(Calendar.DAY_OF_YEAR, 1);
            foundDate = true;
        } else if (text.contains("היום") || text.contains("today")) {
            foundDate = true;
        } else {
            Integer target = findWeekday(text);
            if (target != null) {
                int current = due.get(Calendar.DAY_OF_WEEK);
                int delta = (target - current + 7) % 7;
                if (delta == 0) delta = 7;
                due.add(Calendar.DAY_OF_YEAR, delta);
                foundDate = true;
            }
        }

        int hour = 9, minute = 0;
        boolean foundTime = false;
        Matcher m = COLON_TIME.matcher(text);
        if (m.find()) {
            hour = Integer.parseInt(m.group(1));
            minute = Integer.parseInt(m.group(2));
            foundTime = true;
        } else {
            m = WORD_TIME.matcher(text);
            if (m.find()) {
                hour = Integer.parseInt(m.group(1));
                minute = m.group(2) == null ? 0 : Integer.parseInt(m.group(2));
                foundTime = true;
            }
        }

        if (!foundDate && !foundTime) return new Due(0L, false, false);
        if (!foundDate && foundTime) {
            Calendar candidate = (Calendar) base.clone();
            candidate.set(Calendar.HOUR_OF_DAY, hour);
            candidate.set(Calendar.MINUTE, minute);
            candidate.set(Calendar.SECOND, 0);
            candidate.set(Calendar.MILLISECOND, 0);
            if (candidate.getTimeInMillis() <= base.getTimeInMillis()) candidate.add(Calendar.DAY_OF_YEAR, 1);
            return new Due(candidate.getTimeInMillis(), true, true);
        }

        due.set(Calendar.HOUR_OF_DAY, hour);
        due.set(Calendar.MINUTE, minute);
        due.set(Calendar.SECOND, 0);
        due.set(Calendar.MILLISECOND, 0);
        return new Due(due.getTimeInMillis(), true, foundTime);
    }

    private static Integer findWeekday(String text) {
        Map<String, Integer> days = new HashMap<>();
        days.put("יום ראשון", Calendar.SUNDAY); days.put("ראשון", Calendar.SUNDAY);
        days.put("יום שני", Calendar.MONDAY); days.put("שני", Calendar.MONDAY);
        days.put("יום שלישי", Calendar.TUESDAY); days.put("שלישי", Calendar.TUESDAY);
        days.put("יום רביעי", Calendar.WEDNESDAY); days.put("רביעי", Calendar.WEDNESDAY);
        days.put("יום חמישי", Calendar.THURSDAY); days.put("חמישי", Calendar.THURSDAY);
        days.put("יום שישי", Calendar.FRIDAY); days.put("שישי", Calendar.FRIDAY);
        days.put("שבת", Calendar.SATURDAY);
        days.put("sunday", Calendar.SUNDAY); days.put("monday", Calendar.MONDAY);
        days.put("tuesday", Calendar.TUESDAY); days.put("wednesday", Calendar.WEDNESDAY);
        days.put("thursday", Calendar.THURSDAY); days.put("friday", Calendar.FRIDAY); days.put("saturday", Calendar.SATURDAY);
        for (Map.Entry<String, Integer> e : days.entrySet()) if (text.contains(e.getKey())) return e.getValue();
        return null;
    }

    public static final class Result {
        public boolean isTask;
        public int confidence;
        public String title;
        public String originalText;
        public long dueAt;
        public String priority;
    }

    private static final class Due {
        final long millis; final boolean foundDate; final boolean foundTime;
        Due(long millis, boolean foundDate, boolean foundTime) { this.millis = millis; this.foundDate = foundDate; this.foundTime = foundTime; }
    }
}
