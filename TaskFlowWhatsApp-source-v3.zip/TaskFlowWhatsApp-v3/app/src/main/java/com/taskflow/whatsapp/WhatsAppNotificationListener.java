package com.taskflow.whatsapp;

import android.app.Notification;
import android.app.Person;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;

public class WhatsAppNotificationListener extends NotificationListenerService {
    private static final String WA = "com.whatsapp";
    private static final String WA_BUSINESS = "com.whatsapp.w4b";

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();
        if (!WA.equals(pkg) && !WA_BUSINESS.equals(pkg)) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        Bundle extras = n.extras;

        MessageSnapshot snapshot = latestMessage(extras, sbn.getPostTime());
        String sender = snapshot.sender;
        String text = snapshot.text;
        long when = snapshot.when > 0 ? snapshot.when : (sbn.getPostTime() > 0 ? sbn.getPostTime() : System.currentTimeMillis());

        if (text.isEmpty() || looksLikeSummary(sender, text)) return;

        TaskParser.Result parsed = TaskParser.parse(text, when);
        if (!parsed.isTask) return;

        long bucket = when / 120000L; // collapse notification refreshes, not genuinely later messages.
        String sourceKey = pkg + "|" + sender + "|" + text + "|" + bucket;

        String imagePath = saveMessageImage(snapshot.dataMimeType, snapshot.dataUri, sourceKey);
        if (imagePath.isEmpty()) imagePath = saveNotificationPicture(extras, sourceKey);

        boolean added = new TaskStore(this).addIncoming(sender, parsed, when, sourceKey, imagePath);
        if (!added && !imagePath.isEmpty()) new File(imagePath).delete();
        if (added) {
            sendBroadcast(new android.content.Intent("com.taskflow.whatsapp.TASKS_CHANGED").setPackage(getPackageName()));
        }
    }

    private MessageSnapshot latestMessage(Bundle extras, long fallbackWhen) {
        MessageSnapshot out = new MessageSnapshot();
        out.sender = stringOf(extras.getCharSequence(Notification.EXTRA_TITLE));
        out.text = stringOf(extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
        if (out.text.isEmpty()) out.text = stringOf(extras.getCharSequence(Notification.EXTRA_TEXT));
        out.when = fallbackWhen;

        if (Build.VERSION.SDK_INT >= 30) {
            Parcelable[] bundles = extras.getParcelableArray(Notification.EXTRA_MESSAGES);
            List<Notification.MessagingStyle.Message> messages = Notification.MessagingStyle.Message.getMessagesFromBundleArray(bundles);
            if (messages != null && !messages.isEmpty()) {
                Notification.MessagingStyle.Message latest = messages.get(messages.size() - 1);
                String latestText = stringOf(latest.getText());
                if (!latestText.isEmpty()) out.text = latestText;
                if (latest.getTimestamp() > 0) out.when = latest.getTimestamp();

                if (Build.VERSION.SDK_INT >= 28) {
                    Person person = latest.getSenderPerson();
                    if (person != null && person.getName() != null) {
                        String actualSender = stringOf(person.getName());
                        if (!actualSender.isEmpty()) out.sender = actualSender;
                    }
                } else {
                    String actualSender = stringOf(latest.getSender());
                    if (!actualSender.isEmpty()) out.sender = actualSender;
                }
                out.dataMimeType = latest.getDataMimeType();
                out.dataUri = latest.getDataUri();
            }
        }
        return out;
    }

    private String saveMessageImage(String mimeType, Uri uri, String key) {
        if (mimeType == null || uri == null || !mimeType.toLowerCase().startsWith("image/")) return "";
        File out = imageFile(key, ".img");
        if (out == null) return "";
        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream fos = new FileOutputStream(out)) {
            if (in == null) return "";
            byte[] buffer = new byte[16 * 1024];
            int read;
            long total = 0;
            final long max = 12L * 1024L * 1024L;
            while ((read = in.read(buffer)) >= 0) {
                total += read;
                if (total > max) throw new IllegalStateException("image too large");
                fos.write(buffer, 0, read);
            }
            return out.getAbsolutePath();
        } catch (Exception ignored) {
            out.delete();
            return "";
        }
    }

    private String saveNotificationPicture(Bundle extras, String key) {
        Bitmap bitmap = null;
        Object raw = extras.get(Notification.EXTRA_PICTURE);
        if (raw instanceof Bitmap) bitmap = (Bitmap) raw;

        if (bitmap == null && Build.VERSION.SDK_INT >= 31) {
            Object rawIcon = extras.get(Notification.EXTRA_PICTURE_ICON);
            if (rawIcon instanceof Icon) {
                try {
                    Drawable drawable = ((Icon) rawIcon).loadDrawable(this);
                    if (drawable instanceof BitmapDrawable) bitmap = ((BitmapDrawable) drawable).getBitmap();
                } catch (Exception ignored) {}
            }
        }

        if (bitmap == null) return "";
        File out = imageFile(key, ".jpg");
        if (out == null) return "";
        try (FileOutputStream fos = new FileOutputStream(out)) {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 86, fos)) {
                out.delete();
                return "";
            }
            return out.getAbsolutePath();
        } catch (Exception ignored) {
            out.delete();
            return "";
        }
    }

    private File imageFile(String key, String suffix) {
        try {
            File dir = new File(getFilesDir(), "incoming_images");
            if (!dir.exists() && !dir.mkdirs()) return null;
            return new File(dir, Integer.toHexString(key.hashCode()) + suffix);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String stringOf(CharSequence cs) { return cs == null ? "" : cs.toString().trim(); }

    private static boolean looksLikeSummary(String sender, String text) {
        String s = (sender + " " + text).toLowerCase();
        return s.matches(".*\\b[0-9]+ (new )?messages?\\b.*") || s.contains("הודעות חדשות") || s.contains(" הודעות מ-");
    }

    private static final class MessageSnapshot {
        String sender = "WhatsApp";
        String text = "";
        long when;
        String dataMimeType;
        Uri dataUri;
    }
}
