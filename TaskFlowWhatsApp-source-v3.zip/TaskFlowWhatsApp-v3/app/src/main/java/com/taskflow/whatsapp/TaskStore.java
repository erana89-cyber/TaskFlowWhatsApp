package com.taskflow.whatsapp;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public final class TaskStore {
    private static final String PREFS = "taskflow_store";
    private static final String KEY_TASKS = "tasks";
    private static final String KEY_SEEN = "seen_keys";
    private static final String KEY_AUTO = "auto_add_strong";
    private final SharedPreferences prefs;

    public TaskStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized boolean addIncoming(String sender, TaskParser.Result parsed, long timestamp, String sourceKey, String imagePath) {
        if (parsed == null || !parsed.isTask || parsed.originalText == null || parsed.originalText.trim().isEmpty()) return false;
        JSONArray seen = readArray(KEY_SEEN);
        for (int i = 0; i < seen.length(); i++) {
            if (sourceKey.equals(seen.optString(i))) return false;
        }

        TaskItem item = new TaskItem();
        item.id = UUID.randomUUID().toString();
        item.sender = safe(sender, "WhatsApp");
        item.title = safe(parsed.title, parsed.originalText);
        item.text = parsed.originalText.trim();
        item.createdAt = timestamp > 0 ? timestamp : System.currentTimeMillis();
        item.dueAt = parsed.dueAt;
        item.priority = safe(parsed.priority, "normal");
        item.confidence = parsed.confidence;
        item.status = isAutoAddStrong() && parsed.confidence >= 85 ? "active" : "suggested";
        item.source = "whatsapp";
        item.imagePath = safe(imagePath, "");

        JSONArray tasks = readArray(KEY_TASKS);
        tasks.put(item.toJson());
        seen.put(sourceKey);
        trimArray(seen, 400);
        prefs.edit().putString(KEY_TASKS, tasks.toString()).putString(KEY_SEEN, seen.toString()).apply();
        return true;
    }

    public synchronized void addManual(String text) {
        if (text == null || text.trim().isEmpty()) return;
        TaskParser.Result parsed = TaskParser.parse(text, System.currentTimeMillis());
        TaskItem item = new TaskItem();
        item.id = UUID.randomUUID().toString();
        item.sender = "ידני";
        item.title = safe(parsed.title, text.trim());
        item.text = text.trim();
        item.createdAt = System.currentTimeMillis();
        item.dueAt = parsed.dueAt;
        item.priority = safe(parsed.priority, "normal");
        item.confidence = 100;
        item.status = "active";
        item.source = "manual";
        item.imagePath = "";
        JSONArray tasks = readArray(KEY_TASKS);
        tasks.put(item.toJson());
        prefs.edit().putString(KEY_TASKS, tasks.toString()).apply();
    }

    public boolean isAutoAddStrong() { return prefs.getBoolean(KEY_AUTO, true); }
    public void setAutoAddStrong(boolean enabled) { prefs.edit().putBoolean(KEY_AUTO, enabled).apply(); }

    public synchronized List<TaskItem> all() {
        JSONArray tasks = readArray(KEY_TASKS);
        List<TaskItem> result = new ArrayList<>();
        for (int i = 0; i < tasks.length(); i++) {
            JSONObject o = tasks.optJSONObject(i);
            if (o != null) result.add(TaskItem.fromJson(o));
        }
        Collections.sort(result, Comparator.comparingLong((TaskItem t) -> t.createdAt).reversed());
        return result;
    }

    public synchronized void updateStatus(String id, String status) {
        JSONArray tasks = readArray(KEY_TASKS);
        for (int i = 0; i < tasks.length(); i++) {
            JSONObject o = tasks.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) {
                try { o.put("status", status); } catch (JSONException ignored) {}
                break;
            }
        }
        prefs.edit().putString(KEY_TASKS, tasks.toString()).apply();
    }

    public synchronized void delete(String id) {
        JSONArray tasks = readArray(KEY_TASKS);
        JSONArray out = new JSONArray();
        for (int i = 0; i < tasks.length(); i++) {
            JSONObject o = tasks.optJSONObject(i);
            if (o == null || !id.equals(o.optString("id"))) out.put(o);
        }
        prefs.edit().putString(KEY_TASKS, out.toString()).apply();
    }

    private JSONArray readArray(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); }
        catch (JSONException e) { return new JSONArray(); }
    }

    private static void trimArray(JSONArray a, int max) {
        while (a.length() > max) a.remove(0);
    }

    private static String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    public static class TaskItem {
        public String id;
        public String sender;
        public String title;
        public String text;
        public long createdAt;
        public long dueAt;
        public String priority;
        public int confidence;
        public String status;
        public String source;
        public String imagePath;

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id); o.put("sender", sender); o.put("title", title); o.put("text", text);
                o.put("createdAt", createdAt); o.put("dueAt", dueAt); o.put("priority", priority); o.put("confidence", confidence);
                o.put("status", status); o.put("source", source); o.put("imagePath", imagePath);
            } catch (JSONException ignored) {}
            return o;
        }

        static TaskItem fromJson(JSONObject o) {
            TaskItem t = new TaskItem();
            t.id = o.optString("id");
            t.sender = o.optString("sender", "WhatsApp");
            t.text = o.optString("text");
            t.title = o.optString("title", t.text);
            t.createdAt = o.optLong("createdAt", System.currentTimeMillis());
            t.dueAt = o.optLong("dueAt", 0L);
            t.priority = o.optString("priority", "normal");
            t.confidence = o.optInt("confidence", 0);
            t.status = o.optString("status", "suggested");
            t.source = o.optString("source", "manual");
            t.imagePath = o.optString("imagePath", "");
            return t;
        }
    }
}
