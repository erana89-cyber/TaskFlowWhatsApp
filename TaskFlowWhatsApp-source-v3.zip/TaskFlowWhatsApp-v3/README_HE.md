# TaskFlow WhatsApp – Android Native v0.3.0

אפליקציית Android מקומית לניהול משימות מתוך התראות WhatsApp ו-WhatsApp Business.

## מה היא עושה
- מאזינה רק להתראות של WhatsApp ו-WhatsApp Business לאחר אישור מפורש של Notification Access.
- כוללת גם התראות של צ'אטים מושתקים, כדי שלא לפספס בקשות.
- בקבוצות, מנסה להשתמש בשם השולח האמיתי מתוך Android MessagingStyle.
- מסננת שיחות רגילות ומזהה ניסוחים משימתיים בעברית ובאנגלית.
- מחלצת תאריך/יום ושעה, למשל: היום, מחר, יום שני, 14:30.
- מסמנת דחיפות לפי מילים כמו דחוף, בהקדם, ASAP.
- בקשות ברורות מאוד יכולות להיכנס אוטומטית למשימות; אחרות נכנסות ל-Inbox לאישור.
- מנסה לשמור תמונה רק כאשר Android/WhatsApp חושפים אותה כחלק מההתראה או כ-URI נגיש של הודעת MessagingStyle.
- כל הנתונים נשמרים מקומית במכשיר. אין לאפליקציה הרשאת INTERNET.

## מגבלה חשובה לגבי תמונות
Android אינו מבטיח שאפליקציית Notification Listener תקבל את קובץ המדיה המקורי מכל הודעת WhatsApp. לכן טקסט אמין הרבה יותר; תמונה נשמרת רק אם WhatsApp חשף אותה בפועל להתראה.

## בנייה ל-APK
הפרויקט כולל GitHub Actions ב-`.github/workflows/build-apk.yml`.
ה-Workflow מתקין JDK 17, Android SDK Platform 36 / Build Tools 36.0.0 ו-Gradle 9.6.0, ואז מריץ `assembleDebug` ומעלה artifact בשם `TaskFlow-debug-apk`.

Android Gradle Plugin: 9.4.0
Gradle: 9.6.0
compileSdk / targetSdk: 36
minSdk: 26

## התקנה ראשונה
1. מתקינים את ה-APK.
2. פותחים TaskFlow.
3. לוחצים על "אפשר גישה להתראות WhatsApp".
4. מאשרים ל-TaskFlow גישה להתראות במערכת Android.
5. חוזרים לאפליקציה ומוודאים שמופיע "קליטת WhatsApp פעילה".

## פרטיות
Notification Access היא הרשאה רגישה. TaskFlow v0.3.0 לא שולח את תוכן ההתראות החוצה; עיבוד הטקסט והאחסון מתבצעים מקומית בלבד.
